<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

    <title> Har Ki Dun Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* DOUBLE BOX */
        /* .double-box{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .box{
            flex:1;
            min-width:350px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .box h3{
            color:#40916c;
            margin-bottom:15px;
        }

        .box ul{
            margin-left:20px;
        }

        .box li{
            margin-bottom:12px;
        } */

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:10px;
            margin-bottom: 40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
</style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/har_ki_dun.avif">

    <div class="overlay"></div>

    <div class="hero-text">

        <h1>Har Ki Dun Trek</h1>

        <p>The Valley of Gods in the Garhwal Himalayas</p>

    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

        <h2 class="section-title">
            Why Is Har Ki Dun A Must-Do Trek?
        </h2>
        <p>
           Panoramic Mountain Views: Marvel at snow-capped peaks such as Swargarohini, Black Peak, and Bandarpoonch, which create a majestic backdrop throughout the trek.
           <br>
            Traditional Himalayan Villages: Experience authentic Garhwali culture by visiting remote villages like Osla and Sankri, known for their unique architecture and warm hospitality.
        </p>
        <br>
        <p>
            Diverse Wildlife: Spot Himalayan Monal (state bird of Uttarakhand), langurs, and possibly elusive leopards in their natural habitat.<br>
            Floral Diversity: Trek through forests rich with pine, oak, and rhododendron trees, especially vibrant during the blooming season in summer.
        </p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
            <h3>Basic Information</h3>
            <p><b>Trek Name:</b>Har Ki Dun Trek</p>
            <p><b>Duration:</b> 7 Days </p>
            <p><b>Base Camp:</b> Sankri</p>
            <p><b>Season:</b> Summer</p>
            <p><b>Months: </b> April to October</p>
            <p><b>District:</b> Uttarkashi</p>
        </div>

        <div class="card">
            <h3>Trek Details</h3>
            <p><b>Country:</b> India</p>
            <p><b>Altitude:</b> 12,500 ft</p>
            <p><b>Difficulty:</b> Easy to Moderate</p>
            <p><b>Accommodation:</b> Camping (Triple/Quad Sharing) & Guesthouse</p>
            <p><b>Meals:</b> Meals while on trek & at Hotel/Guesthouse (Veg) ( Breakfast & Dinner)</p>
            <p><b>Location & Distance: </b>  Uttarakhand, Indian Himalayas. 45 Km</p>
        </div>

        <div class="card">
            <h3>Highlights</h3>
            <p><b>Services:</b> Dehradun to Dehradun</p>
            <p><b>Meeting Point:</b> (Pickup/Drop Point): Prince Chowk, Dehradun</p>
            <p><b>Reporting Time:</b> 6:00 AM</p>
            <p><b>Drop Time: </b> 6:30 PM – 7:30 PM (subject to weather/road conditions)</p>
        </div>

    </div>

    <!-- WHO CAN PARTICIPATE -->
    <!-- <div class="double-box">

        <div class="box">

            <h3>Who Can Participate?</h3>

            <ul>
                <li>Age 10 Years and Above</li>
                <li>First timers can apply; previous trekking experience is more appreciated.</li>
                <li>The climber must be fit and have sufficient stamina to cover 5 km of distance in 35 min or 10 km in 80 min without stress.</li>
            </ul>

        </div>

        <div class="box">

            <h3>Travel Tips</h3>
            <ul>
                <li>Carry Good Trekking Shoes</li>
                <li>Bring Warm Clothes & Raincoat</li>
                <li>Keep A Water Bottle</li>
                <li>Follow Trek Leader Instructions</li>
            </ul>
        </div>
    </div> -->
     <h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/har_ki_dun1.jpg">
        <img src="../gallery/har_ki_dun2.avif">
        <img src="../gallery/har_ki_dun3.jpeg">
        <img src="../gallery/har_ki_dun4.jpg">
    </div>
    <br>
    <!-- PRICE -->
    <div class="price">
        <h2>₹ 14,000 / Person</h2>
        <p>Inclusive Of Stay, Meals & Trek Support</p>
    </div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

        <div class="day">
            <h3>Day 1 : Arrival Day – Dehradun to Sankri Village (210 km drive)</h3>
            <ul>
                <li>The drive covers 210 km over approximately 9 hours through scenic Himalayan roads.</li>
                <li>Accommodation at comfortable Homestays in Sankri.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 2 : Sankri to Pauni Garaat via Dharkot</h3>
            <ul>
                <li>Drive 10 km from Sankri to Dharkot village, approx. 1.5 hours.</li>
                <li>Trek 4 km (approx. 3 hours) from Dharkot to Pauni Garaat campsite at 7,000 ft (2,100 m) altitude.</li>
                <li>Packed lunch provided; overnight camping with dinner at Pauni Garaat.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 3 : Pauni Garaat to Kalkattidhar/Boslo</h3>
            <ul>
                <li>Longer trek of 11 km with steeper ascent rewarding you with stunning meadows, waterfalls, and rich biodiversity.</li>
                <li>Pass through Osla village, the last inhabited village en route to Har Ki Dun.</li>
                <li> Overnight camping at Kalkattidhar with panoramic views and acclimatization.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 4 : Boslo/Kalkattidhar to Har Ki Dun (6 km round trip)</h3>
            <ul>
                <li>7-8 hour trek; easy ascent to Har Ki Dun valley followed by moderate climb to Maninda Lake.</li>
                <li>Explore vibrant meadows, the Supin River course, and surrounding Bhojpatra forests.</li>
                <li>Visit a beautiful waterfall on the way; plenty of fresh water sources available.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 5 : Boslo/Kalkattidhar to Pauni Garaat via Osla (11 km trek)</h3>
            <ul>
                <li>Return trek to Pauni Garaat campsite.</li>
                <li>Walk through Osla village to experience local Garhwali culture and traditions.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 6 : Pauni Garaat to Sankri via Dharkot (Trek 4 km, 3 hrs; Drive 20 km, 1 hr)</h3>
            <ul>
                <li>Morning trek from Pauni Garaat to Dharkot.</li>
                <li>Drive back to Sankri for rest and overnight stay in guesthouse.</li>   
            </ul>
        </div>

           <div class="day">
            <h3>Day 7 :  Departure from Sankri to Dehradun (210 km, 8-9 hours drive)</h3>
            <ul>
                <li>Conclude the Har Ki Dun trek and begin drive back to Dehradun.</li>
                <li>Expected arrival in Dehradun by late afternoon or early evening.</li>   
            </ul>
        </div>

    </div>
   

    </div>
    <!-- BOOK BUTTON -->
    <div class="book">

        <a href="../booking.php?trek=Har Ki Dun">
            <button >
                Book Now
            </button>
            
        </a>
    </div>

</div>

</body>
</html>