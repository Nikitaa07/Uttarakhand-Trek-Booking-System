<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

    <title>Badrinath and Kedarnath Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* DOUBLE BOX */
        /* .double-box{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .box{
            flex:1;
            min-width:350px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .box h3{
            color:#40916c;
            margin-bottom:15px;
        }

        .box ul{
            margin-left:20px;
        }

        .box li{
            margin-bottom:12px;
        } */

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/Badrinath_Kedarnath.jpg">

    <div class="overlay"></div>

    <div class="hero-text">

        <h1>BADRINATH & KEDARNATH</h1>

        <p>Sacred Himalayan Pilgrimage & Trekking Experience</p>

    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

        <h2 class="section-title">
            Why Is Badrinath & Kedarnath A Must-Do Journey?
        </h2>

        <p>
            Badrinath and Kedarnath are among the most revered pilgrimage and trekking
            destinations in India, offering a unique blend of spiritual significance,
            natural beauty, and Himalayan adventure. Nestled in the Garhwal Himalayas
            of Uttarakhand, these sacred sites attract thousands of devotees and
            travelers every year.
        </p>

        <br>

        <p>
            Spiritual Significance: Kedarnath is one of the twelve Jyotirlingas
            of Lord Shiva and an important part of the Char Dham Yatra. The journey to
            Kedarnath is considered both a physical and spiritual quest, believed to
            bring blessings and moksha (liberation).
        </p>

    </div>

<!-- INFO CARDS (YOUR DATA EXACT SAME) -->
<div class="cards">

    <div class="card">
        <h3>Basic Information</h3>
        <p><b>Trek Name:</b> Badrinath and Kedarnath Trek</p>
        <p><b>Days:</b> 5 Days</p>
        <p><b>Season:</b> Summer</p>
        <p><b>Months:</b> April to October</p>
        <p><b>District:</b> Badrinath (Chamoli), Kedarnath (Rudraprayag)</p>
    </div>

    <div class="card">
        <h3>Trek Details</h3>
        <p><b>Country:</b> India</p>
        <p><b>Altitude:</b> 11,755 ft (3,583 m)</p>
        <p><b>Grade:</b> Easy to Moderate</p>
        <p><b>Stay:</b> Triple/Quad Guesthouse</p>
        <p><b>Food:</b> Vegetarian meals on trek & at hotel/guesthouse (Breakfast & Dinner)</p>
        <p><b>Location & Distance:</b> Uttarakhand, Indian Himalayas</p>
    </div>

    <div class="card">
        <h3>Highlights</h3>
        <p><b>All-inclusive Services:</b> Haridwar to Haridwar</p>
        <p><b>Meeting Point:</b> Haridwar Railway Station (Pickup/Drop)</p>
        <p><b>Reporting Time:</b> 6:00 AM</p>
        <p><b>Drop Time:</b> 6:30 PM – 7:30 PM (subject to weather/road conditions)</p>
        <p><b>Please be punctual for all departures.</b></p>
    </div>

</div>

<!-- WHO CAN PARTICIPATE -->
<!-- <div class="double-box">

    <div class="box">

        <h3>Who Can Participate?</h3>

        <ul>
            <li>Age 10 Years and Above</li>
            <li>First timers can apply; previous trekking experience is more appreciated.</li>
            <li>The climber must be fit and have sufficient stamina to cover 5 km of distance in 35 min or 10 km in 80 min without stress.</li>
        </ul>

    </div>

    <div class="box">

        <h3>Travel Tips</h3>
        <ul>
            <li>Carry Good Trekking Shoes</li>
            <li>Bring Warm Clothes & Raincoat</li>
            <li>Keep A Water Bottle</li>
            <li>Follow Trek Leader Instructions</li>
        </ul>
    </div>
</div> -->

    <h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/Badrinath_Kedarnath1.jpg">
        <img src="../gallery/Badrinath_Kedarnath2.jpg">
        <img src="../gallery/Badrinath_Kedarnath3.jpg">
        <img src="../gallery/Badrinath_Kedarnath4.jpg">
    </div>
    <br>
<!-- PRICE -->
<div class="price">
    <h2>₹ 12,000 / Person</h2>
    <p>Inclusive Of Stay, Meals & Trek Support</p>
</div>

<!-- ITINERARY -->
<div class="itinerary">

    <h2 class="section-title" style="text-align: center;">Itinerary</h2>

    <div class="day">
        <h3>Day 1: Drive from Haridwar to Guptkashi (255 KM)</h3>
        <ul>
            <li>Pickup from Haridwar/Rishikesh and transfer to Guptkashi in a private vehicle.</li>
            <li>Enjoy stunning views of the Ganga River; witness the confluence at Devprayag.</li>
            <li>Stop at Srinagar for essentials, pass by Rudraprayag and Ukhimath.</li>
            <li>Check in at your Guptkashi hotel.</li>
            <li>If time permits, visit ArdhNarishwar Temple.</li>
            <li>Dinner and overnight stay.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 2: Guptkashi – Sonprayag – Kedarnath | Kedarnath Temple Visit</h3>
        <ul>
            <li>Wake up to Himalayan views.</li>
            <li>Depart early for Kedarnath (around 5 AM).</li>
            <li>Trek from Sonprayag to Kedarnath Temple (16 km one way), enjoying valley and river scenery.</li>
            <li>Lunch stop at Rambara.</li>
            <li>Reach Kedarnath Temple for darshan.</li>
            <li>Overnight stay at Kedarnath.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 3: Kedarnath to Sonprayag to Guptkashi</h3>
        <ul>
            <li>Wake up in the mountains.</li>
            <li>Breakfast at hotel/homestay.</li>
            <li>Trek back to Gaurikund (21 km) and drive to Guptkashi.</li>
            <li>Visit Gauri Kund Temple en route.</li>
            <li>Check-in and overnight in Guptkashi.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 4: Guptkashi to Badrinath (210 KM)</h3>
        <ul>
            <li>Breakfast, then drive to Badrinath—a sacred Char Dham pilgrimage site.</li>
            <li>Enjoy scenic valley views along the Alaknanda River.</li>
            <li>Visit Baniyakund, Joshimath, Govindghat, and Hanuman Chatti on the way.</li>
            <li>Check in at Badrinath hotel.</li>
            <li>Visit Badrinath Temple for evening aarti.</li>
           
        </ul>
    </div>

    <div class="day">
        <h3>Day 5: Badrinath to Rishikesh (Approx. 270 KM) | End of Trip</h3>
        <ul>
            
            <li>Breakfast at hotel.</li>
            <li>Drive back to Rishikesh to conclude your Badrinath-Kedarnath trek and pilgrimage adventure.</li>
        </ul>
    </div>

</div>

<!-- BOOK BUTTON -->
<div class="book">

    <a href="../booking.php?trek=Badrinath and Kedarnath Trek">
        <button >
            Book Now
        </button>
    </a>
</div>

</div>

</body>
</html>