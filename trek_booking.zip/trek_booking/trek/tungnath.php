<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

  <title>Tungnath Yatra</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
     .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* DOUBLE BOX */
        /* .double-box{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .box{
            flex:1;
            min-width:350px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .box h3{
            color:#40916c;
            margin-bottom:15px;
        }

        .box ul{
            margin-left:20px;
        }

        .box li{
            margin-bottom:12px;
        } */

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/tungnath.jpg" alt="Tungnath Trek">

    <div class="overlay"></div>

    <div class="hero-text">
        <h1>Tungnath Trek </h1>
        <p>  Where the earth touches the sky and the soul finds its peace</p>
    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">
  <h2 class="section-title">
    Why Is Tungnath A Must-Do Trek?
</h2>

<p>
    Tungnath is the highest Shiva temple in the world and one of the most rewarding treks in Uttarakhand. The trail passes through beautiful alpine meadows, rhododendron forests, and open Himalayan landscapes, making it ideal for both beginners and experienced trekkers.
</p>

<br>

<p>
    The trek offers breathtaking views of majestic peaks such as Chaukhamba, Nanda Devi, Trishul, and Kedarnath. Adventurous trekkers can continue to Chandrashila Summit, famous for its spectacular 360-degree Himalayan panorama and unforgettable sunrise views. The perfect blend of spirituality, adventure, and natural beauty makes Tungnath a must-do Himalayan trek.
</p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

       <div class="card">
        <h3>Basic Information</h3>
        <p><b>Trek Name:</b> Tungnath Trek</p>
        <p><b>Duration:</b> 4Days / 3 Night</p>
        <p><b>Base Camp:</b> Chopta</p>
        <p><b>Season:</b> Summer | Autumn | Winter</p>
        <p><b>Months:</b> March to June & September to December</p>
        <p><b>District:</b> Rudraprayag</p>
    </div>

    <div class="card">
        <h3>Trek Details</h3>
        <p><b>Country:</b> India</p>
        <p><b>Altitude:</b> 3,680 meters (12,073 feet)</p>
        <p><b>Difficulty:</b> Easy To Moderate</p>
        <p><b>Accommodation:</b> Camps & Guesthouses</p>
        <p><b>Meals:</b> Vegetarian Meals</p>
        <p><b>Location & Distance:</b> Chopta, Uttarakhand | 5 Km Trek (One Way)</p>
    </div>

    <div class="card">
        <h3>Highlights</h3>
        <p><b>All-Inclusive Trek:</b> Rishikesh to Rishikesh</p>
        <p><b>Meeting Point:</b> Natraj Chowk, Rishikesh</p>
        <p><b>Reporting Time:</b> 6:00 AM</p>
        <p><b>Drop Time:</b> 6:00 PM – 8:00 PM (subject to weather/road conditions)</p>
    </div>
    </div>

 
    <h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/tungnath1.jpg">
        <img src="../gallery/tungnath2.jpg">
        <img src="../gallery/tungnath3.jpg">
        <img src="../gallery/tungnath4.jpg">
    </div>
    <br>

    <!-- PRICE -->
  <div class="price">
    <h2>₹ 8,000  / Person</h2>
    <p>Inclusive Of Stay, Meals & Trek Support</p>
</div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

        <div class="day">
        <h3>Day 1 : Haldwani – Chopta (250 Km Drive)</h3>
        <ul>
            <li>Group assembly at Haldwani and departure for Chopta in the morning.</li>
            <li>Arrival at Chopta, check-in, dinner, and overnight stay.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 2 : Chopta – Tungnath Trek</h3>
        <ul>
            <li>After breakfast, begin the trek to the sacred Tungnath Temple.</li>
            <li>Return to Chopta for dinner and overnight stay.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 3 : Chopta – Chandrashila Summit – Chopta</h3>
        <ul>
            <li>Early morning trek to Chandrashila Summit for panoramic Himalayan views.</li>
            <li>Return to Chopta and spend the evening at leisure.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 4 : Chopta – Haldwani (Drive Back)</h3>
        <ul>
            <li>After breakfast, begin the return journey to Haldwani.</li>
            <li>Reach Haldwani by evening and conclude the trek.</li>
        </ul>
    </div>


    <!-- BOOK BUTTON -->
    <div class="book">

       <a href="../booking.php?trek=Tungnath">
    <button>
        Book Now
    </button>
</a>
    </div>

</div>

</body>
</html>