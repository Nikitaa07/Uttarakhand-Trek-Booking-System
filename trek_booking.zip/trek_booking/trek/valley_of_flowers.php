<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

    <title>Valley Of Flowers Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
     .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

       
        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:20px;
            margin-bottom: 30px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/valley_of_flowers.jpg">

    <div class="overlay"></div>

    <div class="hero-text">

        <h1>VALLEY OF FLOWERS</h1>

        <p>One Of India's Most Beautiful Himalayan Treks</p>

    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

        <h2 class="section-title">
            Why Is Valley Of Flowers A Must-Do Trek?
        </h2>
        <p>
            Valley Of Flowers is one of the most famous treks in Uttarakhand.
            Known for its colorful alpine flowers, lush green meadows and
            breathtaking Himalayan scenery, this trek attracts thousands of
            nature lovers every year.
        </p>
        <br>
        <p>
            The trek is beginner friendly and offers an unforgettable experience
            of mountains, waterfalls, rare flowers and peaceful landscapes.
            It is also a UNESCO World Heritage Site, making it one of the most
            special trekking destinations in India.
        </p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
            <h3>Basic Information</h3>
            <p><b>Trek Name:</b> Valley Of Flowers</p>
            <p><b>Duration:</b> 6 Days / 5 Nights</p>
            <p><b>Base Camp:</b> Govindghat/Ghangaria</p>
            <p><b>Season:</b> Summer | Monsoon</p>
            <p><b>Months: </b> June to October (Ideal Blooming Season)</p>
            <p><b>District:</b> Chamoli</p>
        </div>

        <div class="card">
            <h3>Trek Details</h3>
            <p><b>Country:</b> India</p>
            <p><b>Altitude:</b> 12,000 ft</p>
            <p><b>Difficulty:</b> Easy To Moderate</p>
            <p><b>Accommodation:</b> Camps & Guesthouses</p>
            <p><b>Meals:</b> Vegetarian Meals</p>
            <p><b>Location & Distance: </b>  Chamoli District, Uttarakhand. 16 Km approx.</p>
        </div>

        <div class="card">
            <h3>Highlights</h3>
            <p><b>All-Inclusive Trek:</b> Haridwar to Haridwar</p>
            <p><b>Meeting Point:</b> Haridwar Railway Station</p>
            <p><b>Reporting Time:</b> 6:00 AM</p>
            <p><b>Drop Time: </b> 6:30 PM – 7:30 PM (subject to weather/road conditions)</p>
        </div>

    </div>

    <div class="gallery">
        <img src="../gallery/valley_flowers1.jpg">
        <img src="../gallery/valley_flowers2.webp">
        <img src="../gallery/valley_flowers3.jpg">
        <img src="../gallery/valley_flowers4.jpg">
    </div>
    <br>
      

    <!-- PRICE -->
    <div class="price">
        <h2>₹ 13,000 / Person</h2>
        <p>Inclusive Of Stay, Meals & Trek Support</p>
    </div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

        <div class="day">
            <h3>Day 1 : Rishikesh To Joshimath / Pipalkoti (260 Km Drive)</h3>
            <ul>
                <li>Group assembly at 6:30 AM – Pickup at Natraj Chowk / Tapovan Chowk (tentative).</li>
                <li>Scenic drive via Devprayag, Rudraprayag, Karnaprayag & Nandprayag – the sacred Ganga confluences.</li>
                <li>Evening arrival at Joshimath or Pipalkoti. Check-in, dinner, and overnight stay in a guest house.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 2 : Pipalkoti – Govindghat – Pulna – Ghangaria (Trek 10 Km)</h3>
            <ul>
                <li>Briefing after breakfast, then drive to Pulna – the trek starting point.</li>
                <li>Start 10 km trek to Ghangaria (9,800 ft). Path follows river stream and forests.</li>
                <li>Overnight stay at hotel in Ghangaria village.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 3 : Ghangaria to Valley of Flowers & Return (Trek 8 Km Round Trip)</h3>
            <ul>
                <li>Altitude: 11,500 ft | Distance: 4 km one way.</li>
                <li>More than 300+ species of wildflowers: blue poppy, brahma kamal, orchids, primulas.Trek along meadows, glacier view at end of valley.</li>
                <li>No food or camping allowed inside the valley – return to Ghangaria for dinner and rest.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 4 : Ghangaria to Hemkund Sahib & Back (Trek 12 Km Round Trip)</h3>
            <ul>
                <li>Altitude: 15,200 ft – World’s highest Gurudwara.</li>
                <li>Views of Brahma Kamal, Himalayan Blue Poppy & Saptarishi Peaks.</li>
                <li>Return to Ghangaria for night stay.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 5 : Ghangaria – Pulna – Drive to Pipalkoti</h3>
            <ul>
                <li>Descend 10 km to Pulna after breakfast.</li>
                <li>Drive to Joshimath/Pipalkoti.</li>
                <li>Check-in, dinner and night stay at the guest house.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 6 : Pipalkoti to Rishikesh (Drive Back)</h3>
            <ul>
                <li>Depart early with packed memories and reach Rishikesh by evening (6:30 – 7:30 PM).</li>
                <li>Dispersal – ensure onward bookings after 8:30 PM for safety.</li>   
            </ul>
        </div>

    </div>
   

    </div>
    <!-- BOOK BUTTON -->
    <div class="book">

        <a href="../booking.php?trek=Valley Of Flowers">
            <button >
                Book Now
            </button>
        </a>
    </div>

</div>

</body>
</html>