<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

    <title> Roopkund Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* DOUBLE BOX */
        /* .double-box{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .box{
            flex:1;
            min-width:350px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .box h3{
            color:#40916c;
            margin-bottom:15px;
        }

        .box ul{
            margin-left:20px;
        }

        .box li{
            margin-bottom:12px;
        } */

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:10px;
            margin-bottom: 40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
</style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/roopkund.jpg">

    <div class="overlay"></div>

    <div class="hero-text">

        <h1>ROOPKUND</h1>

        <p>The mysterious Skeleton Lake of Uttarakhand</p>

    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

        <h2 class="section-title">
            Why Is Roopkund A Must-Do Trek?
        </h2>
        <p>
            The legendary Roopkund Lake, popularly called Skeleton Lake, is famous for hundreds of ancient human skeletons lying beneath its waters, dating back to the 9th century. This unique aspect adds intrigue and historical mystery to your trekking experience.
        </p>
        <br>
        <p>
            Experience lush forests filled with oak and rhododendrons, tranquil alpine meadows such as Bedni Bugyal and Ali Bedni Bugyal and challenging snowy paths—all in a single unforgettable journey. This trek uniquely blends mystical Himalayan folklore, rich biodiversity, and historical intrigue, culminating at the extraordinary Skeleton Lake.
        </p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
            <h3>Basic Information</h3>
            <p><b>Trek Name:</b>Roopkund Trek</p>
            <p><b>Duration:</b> 8 Days </p>
            <p><b>Base Camp:</b> Lohajung</p>
            <p><b>Season:</b> Summer | Winter</p>
            <p><b>Months: </b> April to November</p>
            <p><b>District:</b> Chamoli</p>
        </div>

        <div class="card">
            <h3>Trek Details</h3>
            <p><b>Country:</b> India</p>
            <p><b>Altitude:</b> 16,500 ft / 5,029 m</p>
            <p><b>Difficulty:</b> Moderate to Difficult</p>
            <p><b>Accommodation:</b> Camping (Triple/Quad Sharing) & Guesthouse</p>
            <p><b>Meals:</b> Meals while on trek & at Hotel/Guesthouse (Veg) ( Breakfast & Dinner)</p>
            
        </div>

        <div class="card">
            <h3>Highlights</h3>
            <p><b>Services:</b> Dehradun to Dehradun</p>
            <p><b>Meeting Point:</b> (Pickup/Drop Point): Prince Chowk, Dehradun</p>
            <p><b>Reporting Time:</b> 6:00 AM</p>
            <p><b>Drop Time: </b> 6:30 PM – 7:30 PM (subject to weather/road conditions)</p>
        </div>

    </div>

    <!-- WHO CAN PARTICIPATE -->
    <!-- <div class="double-box">

        <div class="box">

            <h3>Who Can Participate?</h3>

            <ul>
                <li>Age 10 Years and Above</li>
                <li>First timers can apply; previous trekking experience is more appreciated.</li>
                <li>The climber must be fit and have sufficient stamina to cover 5 km of distance in 35 min or 10 km in 80 min without stress.</li>
            </ul>

        </div>

        <div class="box">

            <h3>Travel Tips</h3>
            <ul>
                <li>Carry Good Trekking Shoes</li>
                <li>Bring Warm Clothes & Raincoat</li>
                <li>Keep A Water Bottle</li>
                <li>Follow Trek Leader Instructions</li>
            </ul>
        </div>
    </div> -->
     <h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/roopkund1.webp">
        <img src="../gallery/roopkund2.webp">
        <img src="../gallery/roopkund3.jpeg">
        <img src="../gallery/roopkund4.jpg">
    </div>
    <br>
    <!-- PRICE -->
    <div class="price">
        <h2>₹ 16,000 / Person</h2>
        <p>Inclusive Of Stay, Meals & Trek Support</p>
    </div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

        <div class="day">
            <h3>Day 1 : Dehradun to Lohajung – Your Adventure Begins</h3>
            <ul>
                <li>Altitude: 7,662 ft</li>
                <li>Drive Distance: 310 km (approx. 10 hours)</li>
                <li>Pickup: 06:00 AM, Prince Chowk, Dehradun</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 2 : Lohajung to Didna Village Trek</h3>
            <ul>
                <li>Trek Distance: 6.5 km</li>
                <li>Altitude: 8,045 ft</li>
                <li>Arrival: Didna by lunchtime</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 3 : Didna to Ali Bugyal – Meadows Exploration</h3>
            <ul>
                <li>Trek Distance: 10.5 km</li>
                <li>Altitude: 11,320 ft</li>
                <li> Accommodation: Tents</li>
                <li>Highlights: Oak, rhododendron forests, scenic alpine meadows</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 4 : Ali Bugyal to Patar Nachauni via Bedni Bugyal & Ghora Lotani</h3>
            <ul>
                <li>Trek Distance: 7 km</li>
                <li>Altitude: 12,818 ft</li>
                <li>Lunch: Patar Nachauni</li>
                <li>Acclimatization: Spend time at Ghora Lotani</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 5 : Patar Nachauni to Bhagwabasa via Kalu Vinayak Temple</h3>
            <ul>
                <li>Trek Distance: 4 km</li>
                <li>Altitude: 14,117 ft</li>
                <li>Trail: Steep ascent to Kalu Vinayak, rocky/snowy descent to Bhagwabasa</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 6 : Bhagwabasa to Roopkund Lake & Back to Bedni Bugyal</h3>
            <ul>
                <li>Trek Distance: 10 km</li>
                <li>Max Altitude: 15,755 ft</li>   
                <li>Departure: Early at 4:00 AM</li>
                <li>Highlights: Skeleton Lake (visible skeletons Aug–Oct), high-altitude trekking experience</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 7 : Trek from Patar Nachauni to Lohajung via Bedni & Wan</h3>
            <ul>
                <li>Trek Distance: 15 km</li>
                <li>Altitude: Descend to 7,662 ft</li>   
                <li>Drive: 45 mins from Wan to Lohajung</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 8 : Lohajung to Dehradun – Journey Ends</h3>
            <ul>
                <li>Drive Distance: 310 km (approx. 10 hours)</li>
            </ul>
        </div>
    </div>
   

    </div>
    <!-- BOOK BUTTON -->
    <div class="book">

        <a href="../booking.php?trek=Roopkund">
            <button >
                Book Now
            </button>
            
        </a>
    </div>

</div>

</body>
</html>