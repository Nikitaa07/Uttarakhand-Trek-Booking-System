<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

    <title>Madmaheshwar Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* DOUBLE BOX */
        /* .double-box{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .box{
            flex:1;
            min-width:350px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .box h3{
            color:#40916c;
            margin-bottom:15px;
        }

        .box ul{
            margin-left:20px;
        }

        .box li{
            margin-bottom:12px;
        } */

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }
        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }

    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/madhyamaheshwar.jpg">

    <div class="overlay"></div>

    <div class="hero-text">

        <h1>MADMAHESHWAR TREK</h1>

        <p>A Sacred Himalayan Journey To One Of The Panch Kedar Temples</p>

    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

        <h2 class="section-title">
            Why Is Madmaheshwar A Must-Do Trek?
        </h2>
        <p>
            Madmaheshwar is one of the five sacred Kedars dedicated to Lord Shiva.
            Reaching this temple is considered spiritually equivalent to visiting
            Kedarnath itself — it’s where devotion meets raw Himalayan beauty.
        </p>
        <br>
        <p>
            Unlike other popular treks, Madmaheshwar offers a tranquil experience.
            The trail passes through traditional Garhwali villages, dense forests,
            and open meadows — without heavy tourist rush.
        </p>
        <br>
        <p>
            From Budha Madmaheshwar, trekkers witness breathtaking views of
            Chaukhamba & Kedarnath Peaks, one of the most stunning Himalayan
            panoramas — snow-clad peaks glowing golden at sunrise. It’s a moment
            that stays for life.
        </p>

    </div>


<!-- INFO CARDS -->
<div class="cards">

    <div class="card">
        <h3>Basic Information</h3>
        <p><b>Trek Name:</b> Madmaheshwar Trek</p>
        <p><b>Days:</b> 4</p>
        <p><b>Base Camp:</b> Ransi</p>
        <p><b>Season:</b> Summer | Autumn</p>
        <p><b>State:</b> Uttarakhand</p>
        <p><b>District:</b> Rudraprayag</p>
    </div>

    <div class="card">
        <h3>Trek Details</h3>
        <p><b>Country:</b> India</p>
        <p><b>Altitude:</b> 10,750 ft</p>
        <p><b>Grade:</b> Moderate to Difficult</p>
        <p><b>Stay:</b> Camping (Triple/Quad Sharing) & Hotel/Guesthouse</p>
        <p><b>Food:</b> Vegetarian Meals (Breakfast & Dinner)</p>
        <p><b>Location & Distance:</b> Uttarakhand, India. 16 Km</p>
    </div>

    <div class="card">
        <h3>Highlights</h3>
        <p><b>Services:</b> Haridwar to Haridwar</p>
        <p><b>Meeting Point:</b> Haridwar Bus Stand</p>
        <p><b>Reporting Time:</b> 6:00 AM</p>
        <p><b>Drop Time:</b> 6:30 PM – 7:30 PM (subject to weather/road conditions)</p>
        <p><b>Note:</b> Please be punctual</p>
    </div>

</div>

<!-- WHO CAN PARTICIPATE
    <div class="double-box">

        <div class="box">

            <h3>Who Can Participate?</h3>

            <ul>
                <li>Age 10 Years and Above</li>
                <li>First timers can apply; previous trekking experience is more appreciated.</li>
                <li>The climber must be fit and have sufficient stamina to cover 5 km of distance in 35 min or 10 km in 80 min without stress.</li>
            </ul>

        </div>

        <div class="box">

            <h3>Travel Tips</h3>
            <ul>
                <li>Carry Good Trekking Shoes</li>
                <li>Bring Warm Clothes & Raincoat</li>
                <li>Keep A Water Bottle</li>
                <li>Follow Trek Leader Instructions</li>
            </ul>
        </div>
    </div> -->

    <h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery//madmaheshwar1.jpg">
        <img src="../gallery/madhyamaheshwar2.jpg">
        <img src="../gallery/madhyamaheshwar3.jpg">
        <img src="../gallery/madmaheshwar4.jpg">
    </div>
    <br>

    <!-- PRICE -->
    <div class="price">
        <h2>₹ 12,000 / Person</h2>
        <p>Inclusive Of Stay, Meals & Trek Support</p>
    </div>


<!-- ITINERARY -->
<div class="itinerary">

    <h2 class="section-title" style="text-align: center;">Itinerary</h2>

    <div class="day">
        <h3>Day 1 : Haridwar – Ransi (Drive 230 Km / 8–9 Hrs)</h3>
        <ul>
            <li>Morning departure from Haridwar.</li>
            <li>Drive along the scenic Alaknanda and Mandakini valleys via Rudraprayag and Ukhimath.</li>
            <li>Reach Ransi village (base camp) by evening.</li>
            <li>Check-in, dinner, and overnight stay at Ransi.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 2 : Ransi – Nanuchatti – Madmaheshwar (Trek 16 Km)</h3>
        <ul>
            <li>Begin the trek from Ransi through pine forests and mountain villages.</li>
            <li>Cross Goundar and Bantoli, enjoying views of waterfalls and meadows.</li>
            <li>Reach Madmaheshwar Temple (3,265 m) — one of the Panch Kedar shrines dedicated to Lord Shiva.</li>
            <li>Evening aarti at the temple.</li>
            <li>Overnight stay at Madmaheshwar.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 3 : Madmaheshwar – Budha Madmaheshwar – Ransi (Trek 16 Km)</h3>
        <ul>
            <li>Early morning hike to Budha Madmaheshwar for breathtaking sunrise views over Chaukhamba and Kedarnath peaks.</li>
            <li>After breakfast, descend back to Ransi.</li>
            <li>Dinner and overnight stay at Ransi.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 4 : Ransi – Haridwar (Drive 230 Km / 8–9 Hrs)</h3>
        <ul>
            <li>After breakfast, drive back to Haridwar.</li>
            <li>Trip ends with blessings of Lord Madmaheshwar and memories of the divine Himalayas.</li>
        </ul>
    </div>

</div>

<!-- BOOK BUTTON -->
<div class="book">

    <a href="../booking.php?trek=Madmaheshwar Trek">
        <button>
            Book Now
        </button>
    </a>

</div>

</body>
</html>

