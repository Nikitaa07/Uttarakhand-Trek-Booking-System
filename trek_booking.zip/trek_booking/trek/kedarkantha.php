<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

<title>Kedarkantha Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* DOUBLE BOX */
        /* .double-box{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .box{
            flex:1;
            min-width:350px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .box h3{
            color:#40916c;
            margin-bottom:15px;
        }

        .box ul{
            margin-left:20px;
        }

        .box li{
            margin-bottom:12px;
        } */

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

         .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/kedrakantha.jpg" alt="Kedarkantha Trek">

<div class="overlay"></div>

<div class="hero-text">
    <h1>KEDARKANTHA TREK</h1>
    <p>One Of The Best Winter Treks In India</p>
</div>
</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

      <h2 class="section-title">
    Why Is Kedarkantha A Must-Do Trek?
</h2>

<p>
    Kedarkantha Trek is one of the most famous winter treks in Uttarakhand.
    Known for its snow-covered trails, pine forests and breathtaking Himalayan
    views, it offers an unforgettable trekking experience.
</p>

<br>

<p>
    The trek is beginner-friendly and rewards trekkers with panoramic views
    of Swargarohini, Black Peak, Bandarpoonch and other Himalayan peaks from
    the summit at 12,500 ft.
</p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
       <h3>Basic Information</h3>

<p><b>Trek Name:</b> Kedarkantha Trek</p>
<p><b>Duration:</b> 5 Days / 4 Nights</p>
<p><b>Base Camp:</b> Sankri Village</p>
<p><b>Season:</b> Winter</p>
<p><b>Months:</b> November to April</p>
<p><b>District:</b> Uttarkashi</p>
        </div>

        <div class="card">
           <h3>Trek Details</h3>

<p><b>Country:</b> India</p>
<p><b>Altitude:</b> 12,500 Ft.</p>
<p><b>Difficulty:</b> Easy To Moderate</p>
<p><b>Accommodation:</b> Camping & Guesthouse</p>
<p><b>Meals:</b> Pure Vegetarian Meals</p>
<p><b>Location & Distance:</b> Uttarakhand, 20 Km Trek</p>
        </div>

        <div class="card">
            <h3>Highlights</h3>

<p><b>Services:</b> Dehradun To Dehradun</p>
<p><b>Meeting Point:</b> Prince Chowk, Dehradun</p>
<p><b>Reporting Time:</b> 6:00 AM</p>
<p><b>Drop Time:</b> 6:30 PM – 7:30 PM</p>
<p><b>Perfect For:</b> Beginners & Snow Lovers</p>
        </div>

    </div>

    <!-- WHO CAN PARTICIPATE -->
    <!-- <div class="double-box">

        <div class="box">

            <h3>Who Can Participate?</h3>

<ul>
    <li>Age 10 Years and Above</li>
    <li>First-time trekkers are welcome.</li>
    <li>Previous trekking experience is beneficial.</li>
    <li>Participants should be physically fit and active.</li>
</ul>
        </div>

        <div class="box">

            <h3>Travel Tips</h3>

<ul>
    <li>Wear comfortable trekking shoes.</li>
    <li>Carry water bottles and light snacks.</li>
    <li>Keep warm clothes during winter months.</li>
    <li>Follow trek leader instructions at all times.</li>
</ul>
        </div>
    </div> -->
<h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/kedarkantha1.webp">
        <img src="../gallery/kedarkantha2.png">
        <img src="../gallery/kedakantha3.jpg">
        <img src="../gallery/kedarkantha4.webp">
    </div>
    <br>
    <!-- PRICE -->
  <div class="price">
    <h2>₹ 10,000 / Person</h2>
    <p>Inclusive Of Stay, Meals & Trek Support</p>
</div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

        <div class="day">
<h3>Day 1 : Dehradun To Sankri (210 Km Drive)</h3>
<ul>
    <li>Altitude: 6,400 ft / 1,920 meters</li>
    <li>Drive via Mussoorie, Kempty Falls, Purola and Mori.</li>
    <li>Reach Sankri by evening, overnight stay at guest house.</li>
    
</ul>
</div>

       <div class="day">
<h3>Day 2 : Sankri To Juda Ka Talab</h3>
<ul>
    <li>4 Km trek through pine and oak forests.</li>
    <li>Altitude: 9,100 ft</li>
    <li>Walk through pine & oak forests, frozen streams, clearings.</li>
    <li>Reach Juda Ka Talab campsite.</li>
    
</ul>
</div>

 <div class="day">
<h3>Day 3 : Juda Ka Talab To Kedarkantha Base Camp</h3>
<ul>
    <li>Altitude: 11,250 ft</li>
    <li>Trek through snowy forests and meadows.</li>
    <li>Beautiful views of Swargarohini and Bandarpoonch.</li>
    <li>Night in tents under the stars</li>
    
</ul>
</div>
<div class="day">
<h3>Day 4 : Kedarkantha Summit & Return To Juda Ka Talab</h3>
<ul>
    <li>Early morning summit trek.</li>
    <li>Reach Kedarkantha Peak (12,500 ft).</li>
    <li>Enjoy 360° Himalayan mountain views.</li>
    <li>Return to Juda Ka Talab campsite.</li>
</ul>
</div>

    <div class="day">
<h3>Day 5 : Juda Ka Talab To Sankri & Drive To Dehradun</h3>
<ul>
    <li>Descend to Sankri after breakfast.</li>
    <li>Drive to Dehradun – arrive by 7:00–8:00 PM</li>
    
</ul>
</div>
    <!-- BOOK BUTTON -->
    <div class="book">
<a href="../booking.php?trek=Kedarkantha Trek">
    <button>
        Book Now
    </button>
</a>
    </div>

</div>

</body>
</html>