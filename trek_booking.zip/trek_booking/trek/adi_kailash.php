<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

    <title>Adi Kailash and Om Parvat Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/adi_kailash.webp">

    <div class="overlay"></div>

    <div class="hero-text">

        <h1>Adi kailash and om parvat Trek </h1>

        <p> India's one of the best Himalayan Treks</p>

    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

        <h2 class="section-title">
            Why Is Adi Kailash and Om Parvat A Must-Do Trek?
        </h2>
        <p>
        Adi Kailash and Om Parvat are among the most spiritually enriching and visually stunning treks in Uttarakhand. Ideal for devotees, adventure seekers, and nature lovers, these treks offer a rare blend of spiritual energy and raw Himalayan beauty. 
        <br>

        1.Spiritual Significance<br>
        2.Breathtaking Himalayan Landscapes<br>
        3.Challenging Yet Rewarding Adventure<br>
        4.Cultural and Mythological Significance<br>
        5.Remote and Peaceful Route<br>
        </p>
        <br>
        <p>
        Adi Kailash (Chhota Kailash) and Om Parvat are two of the most sacred and visually striking peaks in the Kumaon Himalayas of Uttarakhand, near the Indo-Tibetan border. They are highly revered by Hindu pilgrims for their intense spiritual energy and natural beauty.The trek takes you through the stunning Vyas Valley. Pilgrims often take a holy dip in the sacred Parvati Sarovar lake. You can experience the darshan (sacred viewing) of these peaks closely via road drives, vehicle-supported treks, or helicopter tours from hubs like Dharchula or Pithoragarh.
        </p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
            <h3>Basic Information</h3>
            <p><b>Trek Name:</b> Adi kailash and Om parvat</p>
            <p><b>Duration:</b> 7 Days / 6 Nights</p>
            <p><b>Base Camp:</b> Gunji/Nabi Village </p>
            <p><b>Season:</b> Summer | Monsoon</p>
            <p><b>Months: </b> June to October (Ideal Blooming Season)</p>
            <p><b>District:</b> Pithoragarh</p>
        </div>

        <div class="card">
            <h3>Trek Details</h3>
            <p><b>Country:</b> India</p>
            <p><b>Altitude:</b> 5,945 meters (19,505 feet) and the altitude of Om Parvat is 5,590 meters (18,340 feet)</p>
            <p><b>Difficulty:</b> Easy To Moderate</p>
            <p><b>Accommodation:</b> Camps & Guesthouses</p>
            <p><b>Meals:</b> Vegetarian Meals</p>
            <p><b>Location & Distance: </b> Pithoragarh District, Uttarakhand. 50 -60 Km approx.</p>
        </div>

        <div class="card">
    <h3>Highlights</h3>
    <p><b>All-Inclusive Tour:</b> Kathgodam to Kathgodam</p>
    <p><b>Meeting Point:</b> Kathgodam Railway Station</p>
    <p><b>Reporting Time:</b> 6:00 AM</p>
    <p><b>Drop Time:</b> 5:00 PM – 7:00 PM (subject to weather/road conditions)</p>
</div>

    </div>

    h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/adi_kailash1.jpg">
        <img src="../gallery/adi_kailash2.jpg">
        <img src="../gallery/adi_kailash3.webp">
        <img src="../gallery/adi_kailash4.jpg">
    </div>
    <br>
    <!-- PRICE -->
    <div class="price">
        <h2>₹ 20,000 / Person</h2>
        <p>Inclusive Of Stay, Meals & Trek Support</p>
    </div>
<!-- ITINERARY -->
    <div class="itinerary">

    <h2 class="section-title" style="text-align: center;">Itinerary</h2>

    <div class="day">
        <h3>Day 1 :  Haldwani – Pithoragarh</h3>
        <ul>
            <li>Group assembly and departure from Haldwani in the morning.</li>
            <li>Arrival at Pithoragarh, check-in at hotel, dinner and overnight stay.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 2 : Pithoragarh – Dharchula</h3>
        <ul>
            <li>After breakfast, drive towards Dharchula along scenic Himalayan routes.</li>
            <li>Check-in at hotel, dinner and overnight stay at Dharchula.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 3 : Dharchula – Gunji</h3>
        <ul>
            <li>Complete permit formalities and begin the drive to Gunji.</li>
            <li>Reach Gunji, acclimatize to the altitude and stay overnight.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 4 : Gunji – Om Parvat Darshan – Gunji</h3>
        <ul>
            <li>Early morning drive to Nabidhang for Om Parvat Darshan.</li>
            <li>Return to Gunji for dinner and overnight stay.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 5 : Gunji – Jolingkong (Adi Kailash Darshan)</h3>
        <ul>
            <li>Drive to Jolingkong and visit the sacred Adi Kailash region.</li>
            <li>Explore Parvati Sarovar and enjoy Adi Kailash Darshan.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 6 : Jolingkong – Gunji – Dharchula</h3>
        <ul>
            <li>After breakfast, begin the return journey via Gunji.</li>
            <li>Reach Dharchula by evening for dinner and overnight stay.</li>
        </ul>
    </div>

    <div class="day">
        <h3>Day 7 : Dharchula – Pithoragarh – Kathgodam / Haldwani</h3>
        <ul>
            <li>Depart after breakfast and drive back towards Kathgodam/Haldwani.</li>
            <li>Arrival by evening and tour concludes with pleasant memories.</li>
        </ul>
    </div>

</div>
    <!-- BOOK BUTTON -->
    <div class="book">

        <a href="../booking.php?trek=Adi Kailash and Om Parvat">
            <button >
                Book Now
            </button>
        </a>
    </div>

</div>

</body>
</html>