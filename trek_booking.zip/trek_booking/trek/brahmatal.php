<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

  <title>Brahmatal Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
     .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* DOUBLE BOX */
        /* .double-box{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .box{
            flex:1;
            min-width:350px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .box h3{
            color:#40916c;
            margin-bottom:15px;
        }

        .box ul{
            margin-left:20px;
        }

        .box li{
            margin-bottom:12px;
        } */

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/brahmatal.webp" alt="Brahmatal Trek">

    <div class="overlay"></div>

    <div class="hero-text">
        <h1>BRAHMATAL TREK</h1>
        <p>A beautiful snow-covered lake trek in Uttarakhand</p>
    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

      <h2 class="section-title">
    Why Is Brahmatal Trek A Must-Do Adventure?
</h2>

<p>
    Brahmatal Trek is one of the most popular winter treks in Uttarakhand.
    Famous for its snow-covered trails, frozen lakes, dense forests and
    stunning Himalayan views, it offers an unforgettable trekking experience.
</p>

<br>

<p>
    The trek is suitable for beginners as well as experienced trekkers.
    From Brahmatal Lake to the summit views of Mt. Trishul and Nanda Ghunti,
    every day of this trek is filled with natural beauty and adventure.
</p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
       <h3>Basic Information</h3>

<p><b>Trek Name:</b> Brahmatal Trek</p>
<p><b>Duration:</b> 5 Days / 4 Nights</p>
<p><b>Base Camp:</b> Lohajung</p>
<p><b>Season:</b> Summer | Winter</p>
<p><b>Months:</b> November to April</p>
<p><b>District:</b> Chamoli</p>
        </div>

        <div class="card">
            <h3>Trek Details</h3>

<p><b>Country:</b> India</p>
<p><b>Altitude:</b> 12,250 Ft.</p>
<p><b>Difficulty:</b> Easy To Moderate</p>
<p><b>Accommodation:</b> Camping & Guesthouse</p>
<p><b>Meals:</b> Vegetarian Meals</p>
<p><b>Location & Distance:</b> Uttarakhand, 12 Km Trek</p>
        </div>

        <div class="card">
            <h3>Highlights</h3>

<p><b>Services:</b> Dehradun To Dehradun</p>
<p><b>Meeting Point:</b> Prince Chowk, Dehradun</p>
<p><b>Reporting Time:</b> 6:00 AM</p>
<p><b>Drop Time:</b> 6:30 PM – 7:30 PM</p>
<p><b>Airport:</b> Jolly Grant Airport</p>
        </div>

    </div>

   
    <h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/brahmatal1.jpg">
        <img src="../gallery/brahmatal2.webp">
        <img src="../gallery/brahmatal3.webp">
        <img src="../gallery/brahmatal4.webp">
    </div>
    <br>

    <!-- PRICE -->
  <div class="price">
    <h2>₹ 11,000  / Person</h2>
    <p>Inclusive Of Stay, Meals & Trek Support</p>
</div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

        <div class="day">

<h3>Day 1 : Dehradun To Lohajung (300 Km Drive)</h3>

<ul>
    <li>Pickup from Prince Chowk, Dehradun at 6:15 AM.</li>
    <li>Scenic drive through the mountains of Uttarakhand.</li>
    <li>Reach Lohajung by evening.</li>
    <li>Overnight stay at guest house.</li>
</ul>

</div>

        <div class="day">

<h3>Day 2 : Lohajung To Bekaltal (6 Km Trek)</h3>

<ul>
    <li>Trek through forests and mountain trails.</li>
    <li>Reach Bekaltal Lake at 9,950 ft.</li>
    <li>Enjoy sunset views at the lake.</li>
    <li>Overnight stay in tents.</li>
</ul>

</div>

        <div class="day">

<h3>Day 3 : Bekaltal To Brahmatal</h3>

<ul>
    <li>Trek via Jhandi Top with Himalayan views.</li>
    <li>Brahmatal Altitude: 3,200 m / 10,450 ft</li>
    <li>Reach Brahmatal campsite at 10,450 ft.</li>
    <li>Beautiful views of Trishul and Nanda Ghunti.</li>
    <li>Overnight stay in tents.</li>
</ul>

</div>

       <div class="day">

<h3>Day 4 : Brahmatal Top Trek & Return To Lohajung</h3>

<ul>
    <li>Trek to Brahmatal Summit (12,250 ft).</li>
    
    <li>Views include Chaukhamba, Mana, Mandir, Neelkanth, Nilgiri, Nanda Ghunti, Trishul, Maitoli, and Panchachuli Ranges on one side; Shivalik Himalayan Mountains on the other</li>
    <li>Descend back to Lohajung for overnight stay.</li>
</ul>

</div>

        <div class="day">

<h3>Day 5 : Lohajung To Dehradun</h3>

<ul>
    <li>Breakfast at the guest house.</li>
    <li>Drive back to Dehradun.</li>
    <li>Reach by evening (subject to road and weather conditions).</li>
</ul>

</div>
    <!-- BOOK BUTTON -->
    <div class="book">

       <a href="../booking.php?trek=Brahmatal Trek">
    <button>
        Book Now
    </button>
</a>
    </div>

</div>

</body>
</html>