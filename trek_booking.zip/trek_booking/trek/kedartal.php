<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

    <title> Kedartal Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* DOUBLE BOX */
        /* .double-box{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .box{
            flex:1;
            min-width:350px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .box h3{
            color:#40916c;
            margin-bottom:15px;
        }

        .box ul{
            margin-left:20px;
        }

        .box li{
            margin-bottom:12px;
        } */

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:10px;
            margin-bottom: 40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
</style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/kedartal.avif">

    <div class="overlay"></div>

    <div class="hero-text">

        <h1>KEDARTAL</h1>

        <p>Glacial Lake Trek Of Uttarakhand</p>

    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

        <h2 class="section-title">
            Why Is Kedartal A Must-Do Trek?
        </h2>
        <p>
            Kedartal is a pure turquoise glacial lake fed by the Kedar Bamak Glacier. The sight of the lake surrounded by mighty peaks feels unreal and unforgettable. Nowhere else do you get such near, dominating views of Thalay Sagar, Bhrigupanth, Jogin I–III, and other snow-clad peaks. They rise straight above the lake like massive walls of ice.
        </p>
        <br>
        <p>
            Sunrise and sunset at Kedartal are magical. The peaks glow orange, the lake turns golden, and every frame looks like a postcard. The combination of altitude, challenge, scenery, and solitude makes Kedartal one of Uttarakhand’s most powerful high-altitude experiences.
        </p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
            <h3>Basic Information</h3>
            <p><b>Trek Name:</b>Kedartal Trek</p>
            <p><b>Duration:</b> 6 Days </p>
            <p><b>Base Camp:</b> Gangotri</p>
            <p><b>Season:</b> Summer</p>
            <p><b>Months: </b> May | June | October</p>
            <p><b>District:</b> Uttarkashi</p>
        </div>

        <div class="card">
            <h3>Trek Details</h3>
            <p><b>Country:</b> India</p>
            <p><b>Altitude:</b> Approx. 15,500 ft</p>
            <p><b>Difficulty:</b> Moderate to Difficult</p>
            <p><b>Accommodation:</b> Camping (Triple/Quad Sharing) & Guesthouse</p>
            <p><b>Meals:</b> Meals while on trek & at Hotel/Guesthouse (Veg) ( Breakfast & Dinner)</p>
            <p><b>Location & Distance: </b>  Uttarakhand, India. 32 Km</p>
        </div>

        <div class="card">
            <h3>Highlights</h3>
            <p><b>Services:</b> Dehradun to Dehradun</p>
            <p><b>Meeting Point:</b> (Pickup/Drop Point): Prince Chowk, Dehradun</p>
            <p><b>Reporting Time:</b> 6:00 AM</p>
            <p><b>Drop Time: </b> 6:30 PM – 7:30 PM (subject to weather/road conditions)</p>
        </div>

    </div>

    <!-- WHO CAN PARTICIPATE -->
    <!-- <div class="double-box">

        <div class="box">

            <h3>Who Can Participate?</h3>

            <ul>
                <li>Age 10 Years and Above</li>
                <li>First timers can apply; previous trekking experience is more appreciated.</li>
                <li>The climber must be fit and have sufficient stamina to cover 5 km of distance in 35 min or 10 km in 80 min without stress.</li>
            </ul>

        </div>

        <div class="box">

            <h3>Travel Tips</h3>
            <ul>
                <li>Carry Good Trekking Shoes</li>
                <li>Bring Warm Clothes & Raincoat</li>
                <li>Keep A Water Bottle</li>
                <li>Follow Trek Leader Instructions</li>
            </ul>
        </div>
    </div> -->
     <h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/kedartal1.jpg">
        <img src="../gallery/kedartal2.jpg">
        <img src="../gallery/kedartal3.jpg">
        <img src="../gallery/kedartal4.jpg">
    </div>
    <br>
    <!-- PRICE -->
    <div class="price">
        <h2>₹ 20,000 / Person</h2>
        <p>Inclusive Of Stay, Meals & Trek Support</p>
    </div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

        <div class="day">
            <h3>Day 1 : Dehradun to Gangotri</h3>
            <ul>
                <li>Drive: 240 km | 8–9 hours</li>
                <li>Altitude: 10,000 ft</li>
                <li>Early morning drive along the Bhagirathi River, crossing Uttarkashi and Harsil Valley. Reach Gangotri by evening, check in, explore the temple area, and rest.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 2 : Gangotri to Bhoj Kharak</h3>
            <ul>
                <li>Trek Distance: 8 km | 5–6 hours</li>
                <li>Altitude: 12,400 ft</li>
                <li>Start the trek and navigate through rocky paths and reach Bhoj Kharak, a beautiful meadow surrounded by high ridges.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 3 : Bhoj Kharak to Kedar Kharak</h3>
            <ul>
                <li>Trek Distance: 5 km | 4–5 hours</li>
                <li>Altitude: 14,000 ft</li>
                <li> A scenic trek through narrow trails, and stunning views of Thalay Sagar. Kedar Kharak is one of the most picturesque campsites of the trek.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 4 : Kedar Kharak to Kedartal and back to Kedar Kharak</h3>
            <ul>
                <li>Trek Distance: 8 km | 6–7 hours</li>
                <li>Altitude: 16,000 ft (Kedartal)</li>
                <li>Early morning push to Kedartal. Walk through moraine zones, and glacial terrain. Witness the turquoise lake beneath mighty peaks like Thalay Sagar and Bhrigupanth. Return to Kedar Kharak for the night.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 5 : Kedar Kharak to Gangotri</h3>
            <ul>
                <li>Trek Distance: 13 km | 7 hours</li>
                <li>Long descent through Bhoj Kharak back to Gangotri. Reach by evening at the guesthouse.</li>
            </ul>
        </div>

        <div class="day">
            <h3>Day 6 : Gangotri to Dehradun</h3>
            <ul>
                <li>Drive: 240 km | 8–9 hours</li>
                <li>Return drive through Harsil, Uttarkashi, and Mussoorie route. Reach Dehradun by evening, marking the end of the trek.
</li>   
            </ul>
        </div>

    </div>
   

    </div>
    <!-- BOOK BUTTON -->
    <div class="book">

        <a href="../booking.php?trek=Kedartal">
            <button >
                Book Now
            </button>
            
        </a>
    </div>

</div>

</body>
</html>