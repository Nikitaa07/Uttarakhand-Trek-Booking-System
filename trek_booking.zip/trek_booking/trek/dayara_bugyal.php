<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

<title>Dayara Bugyal Trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }

        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        
        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

         .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

    <img src="../trek_image/dyara_bugyal.jpg" alt="Dyara Bugyal Trek">

    <div class="overlay"></div>

    <div class="hero-text">
        <h1>DAYARA BUGYAL TREK</h1>
        <p>One of Uttarakhand’s most beautiful high-altitude grasslands</p>
    </div>

</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

 <h2 class="section-title">
    Why Is Dayara Bugyal A Must-Do Trek?
</h2>

<p>
    Dayara Bugyal is one of the most beautiful meadow treks in Uttarakhand,
    offering vast alpine grasslands, dense oak forests and stunning Himalayan
    views. It is perfect for beginners, families and nature lovers.
</p>

<br>

<p>
    The trek rewards visitors with breathtaking views of Bandarpunch,
    Swargarohini and Black Peak while providing a peaceful camping experience
    amidst untouched Himalayan landscapes.
</p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
   <h3>Basic Information</h3>

<p><b>Trek Name:</b> Dayara Bugyal Trek</p>
<p><b>Duration:</b> 4 Days</p>
<p><b>Base Camp:</b> Raithal</p>
<p><b>Season:</b> Winter</p>
<p><b>Months:</b> November To April</p>
<p><b>District:</b> Uttarkashi</p>
        </div>

        <div class="card">
     <h3>Trek Details</h3>

<p><b>Country:</b> India</p>
<p><b>Altitude:</b> 10,827 Ft.</p>
<p><b>Difficulty:</b> Easy To Moderate</p>
<p><b>Accommodation:</b> Camping & Guesthouse</p>
<p><b>Meals:</b> Vegetarian Meals</p>
<p><b>Location & Distance:</b> Uttarakhand, Garhwal Himalayas 8 Km Loop </p>
        </div>

        <div class="card">
    <h3>Highlights</h3>

<p><b>Views:</b> Bandarpunch & Swargarohini Peaks</p>
<p><b>Meeting Point:</b> Prince Chowk, Dehradun</p>
<p><b>Reporting Time:</b> 6:00 AM</p>
<p><b>Drop Time:</b> 6:30 PM – 7:30 PM</p>
<p><b>Perfect For:</b> Beginners & Families</p>
        </div>

    </div>

  
<h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/dayara_bugyal1.jpg">
        <img src="../gallery/dayara_bugyal2.jpg">
        <img src="../gallery/dayara_bugyal3.jpg">
        <img src="../gallery/dayara_bugyal4.jpg">
    </div>
    <br>
    <!-- PRICE -->
<div class="price">
    <h2>₹ 12,000 / Person</h2>
    <p>Inclusive Of Stay, Meals & Trek Support</p>
</div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

        <div class="day">
<h3>Day 1 : Drive from Dehradun to Raithal Village</h3>

<ul>
    <li>Distance: 190 km (Approx. 7-8 hours drive)</li>
    <li>Altitude Gain: From 2,100 ft to 7,200 ft</li>
    <li>Pass through beautiful Himalayan villages.</li>
    <li>Reach Raithal by evening.</li>
</ul>
</div>

  <div class="day">
<h3>Day 2 : Trek from Raithal to Gui</h3>

<ul>
    <li>5 Km trek through forests and meadows.</li>
    <li>Altitude Gain: From 7,200 ft to 9,500 ft</li>
    <li>Enjoy stunning Himalayan views.</li>
    <li>Overnight stay in tents.</li>
</ul>
</div>

<div class="day">
<h3>Day 3 : Gui To Dayara Bugyal & Return To Gui</h3>

<ul>
    <li>Trek to the famous Dayara Bugyal meadows.(7km)</li>
    <li>Altitude Gain: 9,500 ft to 11,950 ft and back to 9,500 ft</li>
    <li>Explore vast alpine grasslands.</li>
    <li>Return to Gui campsite for overnight stay.</li>
</ul>
</div>
<div class="day">
<h3>Day 4 :  Trek from Gui to Raithal and Drive Back to Dehradun</h3>

<ul>
    <li>Trekking Distance: 5 km (2-3 hours)</li>
    <li>Drive: 190 km (Approx. 7-8 hours)</li>
    <li>Altitude Descent: From 9,500 ft to 5,905 ft and then 1,200 ft</li>
    <li>Drive back to Dehradun.</li>
   
</ul>
</div>

 
    <!-- BOOK BUTTON -->
    <div class="book">
<a href="../booking.php?trek=Dyara Bugyal Trek">
    <button>
        Book Now
    </button>
</a>
    </div>

</div>

</body>
</html>