<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

<title>Aancha top trek</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:#eef3fb;
            color:#333;
        }

        /* NAVBAR */
        .navbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:15px 40px;
            background:rgb(34, 91, 65);
            color:white;
            
        }

        .navbar h2{
            font-size:22px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            margin-left:20px;
            font-weight:bold;
        }

        /* HERO */
        .hero{
            position:relative;
        }
 .hero{
            position:relative;
        }

        .hero img{
            width:100%;
            height:700px;
            object-fit:cover;
        }

        .overlay{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.4);
        }

        .hero-text{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            text-align:center;
            color:white;
        }

        .hero-text h1{
            font-size:60px;
            margin-bottom:10px;
        }

        .hero-text p{
            font-size:20px;
        }


        /* MAIN */
        .container{
            width:90%;
            max-width:1300px;
            margin:auto;
            padding:50px 0;
        }

        .section-title{
            color:#2d6a4f;
            margin-bottom:20px;
            font-size:32px;
        }

        /* ABOUT */
        .about{
            background:white;
            padding:30px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
        }

        .about p{
            line-height:30px;
            font-size:16px;
        }

        /* INFO CARDS FIX HEIGHT */
        .cards{
            display:flex;
            gap:25px;
            flex-wrap:wrap;
            margin-bottom:35px;
        }

        .card{
            flex:1;
            min-width:280px;
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            min-height:370px;
        }

        .card h3{
            color:#40916c;
            margin-bottom:20px;
            text-align:center;
            font-size:22px;
        }

        .card p{
            margin-bottom:12px;
            line-height:26px;
        }

        /* PRICE FIX */
        .price{
            background:#40916c;
            color:white;
            text-align:center;
            padding:40px;
            border-radius:12px;
            margin-bottom:35px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.15);
        }

        .price h2{
            font-size:35px;
        }

        .price p{
            margin-top:10px;
        }

        /* ITINERARY */
        .itinerary{
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0px 3px 12px rgba(0,0,0,0.1);
            
        }

        .day{
            margin-bottom:20px;
            padding:25px;
            border-left:5px solid #2d6a4f;
            background:#f1faee;
            border-radius:8px;
            margin-left: 50px;
            margin-right: 50px;
        }

        .day h3{
            color:#077244;
            margin-bottom:10px;
        }

        .day ul{
            margin-left:20px;
        }

        .day li{
            margin-bottom:8px;
        }

        /* BUTTON */
        .book{
            text-align:center;
            margin-top:40px;
        }

        .book button{
            background:#40916c;
            color:white;
            border:none;
            padding:15px 40px;
            font-size:18px;
            border-radius:8px;
            cursor:pointer;
        }

        .book button:hover{
            background:#2d6a4f;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:15px;
            flex-wrap:wrap;
        }

        .gallery img{
        width:300px;
        height:200px;
       
        border-radius:10px;
       }

        .gallery img:hover{
            transform:scale(1.05);
        }
    </style>

    

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Uttara Trek</h2>
    <div>
        <a href="../choose_trek.php">Treks</a>
        <a href="../contact.php">Contact Us</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">

  <!-- HERO -->

<div class="hero">

<img src="../trek_image/aancha.jpg" alt="Aancha Top Trek">

<div class="overlay"></div>

<div class="hero-text">
    <h1>AANCHA TOP TREK</h1>
    <p>An Offbeat Himalayan Adventure In Uttarakhand</p>
</div>


</div>

<!-- CONTENT -->
<div class="container">

    <!-- ABOUT -->
    <div class="about">

 <h2 class="section-title">
    Why Is Aancha Top A Must-Do Trek?
</h2>

<p>
    Aancha Top is one of Uttarakhand's hidden trekking gems, offering
    untouched landscapes, peaceful trails and breathtaking Himalayan views.
    It is perfect for trekkers looking for an offbeat mountain adventure.
</p>

<br>

<p>
    From dense oak forests and alpine meadows to the stunning summit at
    12,500 ft, the trek delivers a complete Himalayan experience with
    beautiful campsites and panoramic mountain scenery.
</p>
    </div>

    <!-- INFO CARDS (YOUR DATA EXACT SAME) -->
    <div class="cards">

        <div class="card">
       <h3>Basic Information</h3>

<p><b>Trek Name:</b> Aancha Top Trek</p>
<p><b>Duration:</b> 5 Days</p>
<p><b>Base Camp:</b> Ranachatti</p>
<p><b>Season:</b> Winter</p>
<p><b>Months:</b> November - April</p>
<p><b>District:</b> Uttarkashi</p>
        </div>

        <div class="card">
           <h3>Trek Details</h3>

<p><b>Country:</b> India</p>
<p><b>Altitude:</b> 12,500 Ft.</p>
<p><b>Difficulty:</b> Easy To Moderate</p>
<p><b>Accommodation:</b> Camping & Guesthouse</p>
<p><b>Meals:</b> Vegetarian Meals</p>
<p><b>Location & Distance:</b> Uttarakhand, 22 Km Trek</p>
        </div>

        <div class="card">
         <h3>Highlights</h3>

<p><b>Services:</b> Dehradun To Dehradun</p>
<p><b>Meeting Point:</b> Prince Chowk, Dehradun</p>
<p><b>Reporting Time:</b> 7:00 AM</p>
<p><b>Drop Time:</b> 6:30 PM – 7:30 PM</p>
<p><b>Perfect For:</b> Beginners & Nature Lovers</p>
        </div>

    </div>

    <!-- WHO CAN PARTICIPATE -->
    <!-- <div class="double-box">

        <div class="box">

<h3>Who Can Participate?</h3>

<ul>
    <li>Age 10 Years and Above</li>
    <li>First-time trekkers are welcome.</li>
    <li>Previous trekking experience is beneficial.</li>
    <li>Participants should be physically fit and active.</li>
</ul>
        </div>

        <div class="box">
<h3>Travel Tips</h3>

<ul>
    <li>Wear comfortable trekking shoes.</li>
    <li>Carry water bottles and light snacks.</li>
    <li>Keep warm clothes during winter months.</li>
    <li>Be prepared for changing mountain weather.</li>
</ul>
        </div>
    </div> -->

    <h2 class="section-title" style="text-align: center;">Gallery</h2>

    <div class="gallery">
        <img src="../gallery/aancha1.jpg">
        <img src="../gallery/aancha2.webp">
        <img src="../gallery/aancha3.avif">
        <img src="../gallery/aancha4.webp">
    </div>
    <br>
    <!-- PRICE -->
  <div class="price">
    <h2>₹ 11,000 / Person</h2>
    <p>Inclusive Of Stay, Meals & Trek Support</p>
</div>

    <!-- ITINERARY -->
    <div class="itinerary">

        <h2 class="section-title" style="text-align: center;">Itinerary</h2>

       <div class="day">
<h3>Day 1 : Dehradun To Ranachatti</h3>

<ul>
    <li>Pickup from Prince Chowk, Dehradun at 7:00 AM.</li>
    <li>Drive through Mussoorie and Yamunotri Valley.</li>
    <li>Reach Ranachatti by evening.</li>
    <li>Overnight stay at base camp.</li>
</ul>
</div>

  <div class="day">
<h3>Day 2 : Ranachatti To Dinala Camp</h3>

<ul>
    <li>8 Km trek through oak and pine forests.</li>
    <li>Pass beautiful Bam Singh meadows.</li>
    <li>Reach Dinala Camp at 10,500 ft.</li>
    <li>Overnight stay in tents.</li>
</ul>
</div>

<div class="day">
<h3>Day 3 : Dinala Camp To Aancha Camp Via Aancha Top</h3>

<ul>
    <li>Early morning summit push.</li>
    <li>Reach Aancha Top at 12,500 ft.</li>
    <li>Enjoy panoramic Himalayan views.</li>
    <li>Descend to Aancha Camp for overnight stay.</li>
</ul>
</div>
<div class="day">
<h3>Day 4 : Aancha Camp To Ranachatti</h3>

<ul>
    <li>Descend through scenic forest trails.</li>
    <li>Reach Ranachatti base camp.</li>
    <li>Enjoy hot lunch and evening relaxation.</li>
    <li>Overnight stay at base camp.</li>
</ul>
</div>

  <div class="day">
<h3>Day 5 : Ranachatti To Dehradun</h3>

<ul>
    <li>Breakfast at the campsite.</li>
    <li>Drive back through Yamunotri Valley.</li>
    <li>Reach Dehradun by evening.</li>
</ul>
</div>
    <!-- BOOK BUTTON -->


<div class="book">
    <a href="../booking.php?trek=Aancha Top Trek">
        <button>
            Book Now
        </button>
    </a>
</div>


</div>

</body>
</html>